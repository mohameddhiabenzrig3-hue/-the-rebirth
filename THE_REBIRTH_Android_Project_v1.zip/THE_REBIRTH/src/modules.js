export const MODULES = [
  {
    "id": 1,
    "key": "m01",
    "en": "Habit Engine",
    "ar": "محرك العادات",
    "description": "إنشاء العادات اليومية وتسجيل إنجازها ومتابعة الالتزام."
  },
  {
    "id": 2,
    "key": "m02",
    "en": "Discipline Core",
    "ar": "نواة الانضباط",
    "description": "قواعد يومية، التزامات أساسية، ومؤشر تنفيذ."
  },
  {
    "id": 3,
    "key": "m03",
    "en": "Life Dimensions",
    "ar": "أبعاد الحياة",
    "description": "متابعة تطور العقل والجسد والشخصية والمال والعلاقات."
  },
  {
    "id": 4,
    "key": "m04",
    "en": "Command Center",
    "ar": "مركز القيادة",
    "description": "لوحة مركزية للمهام والعادات والأهداف والتقدم."
  },
  {
    "id": 5,
    "key": "m05",
    "en": "Time Intelligence",
    "ar": "ذكاء الوقت",
    "description": "تخطيط اليوم وتوزيع الوقت ومراجعة استعماله."
  },
  {
    "id": 6,
    "key": "m06",
    "en": "Mission System",
    "ar": "نظام المهمات",
    "description": "إنشاء المهمات وتحديد الأولوية والموعد والحالة."
  },
  {
    "id": 7,
    "key": "m07",
    "en": "Streak Engine",
    "ar": "محرك الاستمرارية",
    "description": "حساب سلاسل الإنجاز وأفضل سلسلة لكل عادة."
  },
  {
    "id": 8,
    "key": "m08",
    "en": "Intelligence Engine",
    "ar": "محرك الذكاء",
    "description": "تحليل مؤشرات الأداء وتقديم ملاحظات مبنية على البيانات."
  },
  {
    "id": 9,
    "key": "m09",
    "en": "Human Performance",
    "ar": "الأداء البشري",
    "description": "متابعة الطاقة والنوم والتركيز والأداء اليومي."
  },
  {
    "id": 10,
    "key": "m10",
    "en": "Anti-Habit System",
    "ar": "نظام مكافحة العادات",
    "description": "تسجيل المحفزات والعادات التي تريد تقليلها أو إيقافها."
  },
  {
    "id": 11,
    "key": "m11",
    "en": "Challenge Arena",
    "ar": "ساحة التحديات",
    "description": "تحديات محددة المدة مع أهداف ونتائج."
  },
  {
    "id": 12,
    "key": "m12",
    "en": "Achievement Vault",
    "ar": "خزانة الإنجازات",
    "description": "توثيق الإنجازات والمحطات المهمة."
  },
  {
    "id": 13,
    "key": "m13",
    "en": "Reporting System",
    "ar": "نظام التقارير",
    "description": "ملخصات يومية وأسبوعية ومؤشرات قابلة للتصدير."
  },
  {
    "id": 14,
    "key": "m14",
    "en": "Routine Architect",
    "ar": "مهندس الروتين",
    "description": "بناء روتينات صباحية ومسائية وأسبوعية."
  },
  {
    "id": 15,
    "key": "m15",
    "en": "Deep Focus",
    "ar": "التركيز العميق",
    "description": "جلسات تركيز ومؤقت قابل للتشغيل والإيقاف."
  },
  {
    "id": 16,
    "key": "m16",
    "en": "Smart Habits",
    "ar": "العادات الذكية",
    "description": "ربط العادات بالمحفزات والوقت والسياق."
  },
  {
    "id": 17,
    "key": "m17",
    "en": "Self Audit",
    "ar": "التدقيق الذاتي",
    "description": "مراجعة ذاتية دورية وتقييم صريح."
  },
  {
    "id": 18,
    "key": "m18",
    "en": "Reward & Consequence",
    "ar": "المكافأة والعاقبة",
    "description": "تحديد مكافآت وعواقب شخصية اختيارية."
  },
  {
    "id": 19,
    "key": "m19",
    "en": "Personalization Engine",
    "ar": "محرك التخصيص",
    "description": "تخصيص الاسم والأهداف والمظهر والتفضيلات."
  },
  {
    "id": 20,
    "key": "m20",
    "en": "Notification Intelligence",
    "ar": "ذكاء التنبيهات",
    "description": "إعداد تذكيرات داخل التطبيق؛ إشعارات النظام تحتاج استكمال تكامل Android."
  },
  {
    "id": 21,
    "key": "m21",
    "en": "Data Vault",
    "ar": "خزنة البيانات",
    "description": "نسخ احتياطي واستعادة بيانات JSON محلياً."
  },
  {
    "id": 22,
    "key": "m22",
    "en": "Additional Features",
    "ar": "الميزات الإضافية",
    "description": "مساحة منظمة للميزات المساندة المستقبلية."
  },
  {
    "id": 23,
    "key": "m23",
    "en": "Design System",
    "ar": "نظام التصميم",
    "description": "مكونات وألوان وتخطيطات موحدة."
  },
  {
    "id": 24,
    "key": "m24",
    "en": "System Architecture",
    "ar": "معمارية النظام",
    "description": "فصل الواجهة والمنطق والتخزين وطبقة البيانات."
  },
  {
    "id": 25,
    "key": "m25",
    "en": "Sketchware Pro Integration",
    "ar": "تكامل Sketchware Pro",
    "description": "توثيق نقاط التكامل الممكنة مع Sketchware Pro."
  },
  {
    "id": 26,
    "key": "m26",
    "en": "Implementation Roadmap",
    "ar": "خارطة التنفيذ",
    "description": "مراحل تطوير واختبار وإصدار المشروع."
  },
  {
    "id": 27,
    "key": "m27",
    "en": "Testing System",
    "ar": "نظام الاختبارات",
    "description": "فحوصات سلامة البيانات والوظائف الأساسية."
  },
  {
    "id": 28,
    "key": "m28",
    "en": "Rebirth Score",
    "ar": "نقاط الولادة من جديد",
    "description": "مؤشر تقدمي مبني على إكمال العادات والمهمات."
  },
  {
    "id": 29,
    "key": "m29",
    "en": "Top 10 Features",
    "ar": "أفضل عشر ميزات",
    "description": "عرض أهم عشرة إنجازات/أولويات يحددها المستخدم."
  },
  {
    "id": 30,
    "key": "m30",
    "en": "Final Identity System",
    "ar": "نظام الهوية النهائية",
    "description": "صياغة هوية مستهدفة ومراجعة التقدم نحوها."
  }
];
